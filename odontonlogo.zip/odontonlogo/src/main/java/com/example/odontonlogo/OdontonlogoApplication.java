package com.example.odontonlogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OdontonlogoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdontonlogoApplication.class, args);
	}

}
