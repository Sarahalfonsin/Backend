package com.example.odontonlogo.repository.impl;

import com.example.odontonlogo.repository.IDao;
import com.example.odontonlogo.dominio.Turno;

import java.util.List;
//falta crearlo
public class TurnoDAOH2 implements IDao<Turno> {
    @Override
    public Turno guardar(Turno turno) {
        return null;
    }

    @Override
    public void eliminar(Long id) {

    }

    @Override
    public Turno buscarId(Long id) {
        return null;
    }

    @Override
    public Turno buscar(String email) {
        return null;
    }

    @Override
    public List<Turno> buscarTodos() {
        return null;
    }

    @Override
    public Turno modificar(Turno turno) {
        return null;
    }
}
