package com.example.odontonlogo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OdontonlogoApplicationTests {

	@Test
	void contextLoads() {
	}

}
